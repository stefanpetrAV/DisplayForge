import{c as a,a as e,A as o}from"./store-C_NaKya1.js";a(o,{mode:"standalone",store:e("standalone")}).mount("#app");
