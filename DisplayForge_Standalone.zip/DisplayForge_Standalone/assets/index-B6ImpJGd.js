import{c as p,a,A as e}from"./store-C_NaKya1.js";p(e,{mode:"plugin",store:a("plugin")}).mount("#app");
