import{c as a,a as e,A as o}from"./store-BPKxyBEr.js";a(o,{mode:"standalone",store:e("standalone")}).mount("#app");
