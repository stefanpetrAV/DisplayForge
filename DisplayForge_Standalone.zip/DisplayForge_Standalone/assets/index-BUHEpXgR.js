import{c as p,a,A as e}from"./store-9iiiTr9-.js";p(e,{mode:"plugin",store:a("plugin")}).mount("#app");
