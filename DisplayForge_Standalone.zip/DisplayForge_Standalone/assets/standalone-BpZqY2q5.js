import{c as a,a as e,A as o}from"./store-9iiiTr9-.js";a(o,{mode:"standalone",store:e("standalone")}).mount("#app");
