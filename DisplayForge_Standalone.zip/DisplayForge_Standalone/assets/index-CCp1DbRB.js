import{c as p,a,A as e}from"./store-BPKxyBEr.js";p(e,{mode:"plugin",store:a("plugin")}).mount("#app");
