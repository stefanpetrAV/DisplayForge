import{c as a,a as e,A as o}from"./store-BRCEy1yj.js";a(o,{mode:"standalone",store:e("standalone")}).mount("#app");
