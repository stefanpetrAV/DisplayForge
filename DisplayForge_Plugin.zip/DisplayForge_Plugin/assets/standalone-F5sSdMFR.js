import{c as a,a as e,A as o}from"./store-CQdxmr52.js";a(o,{mode:"standalone",store:e("standalone")}).mount("#app");
