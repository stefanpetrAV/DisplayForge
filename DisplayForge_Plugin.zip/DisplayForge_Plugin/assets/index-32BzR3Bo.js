import{c as p,a,A as e}from"./store-BRCEy1yj.js";p(e,{mode:"plugin",store:a("plugin")}).mount("#app");
