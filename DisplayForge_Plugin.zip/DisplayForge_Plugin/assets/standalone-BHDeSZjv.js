import{c as a,a as e,A as o}from"./store-CpnYSMZ4.js";a(o,{mode:"standalone",store:e("standalone")}).mount("#app");
