import{c as p,a,A as e}from"./store-C_36TxOU.js";p(e,{mode:"plugin",store:a("plugin")}).mount("#app");
