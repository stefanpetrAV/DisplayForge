import{c as a,a as e,A as o}from"./store-BCTFRGNl.js";a(o,{mode:"standalone",store:e("standalone")}).mount("#app");
