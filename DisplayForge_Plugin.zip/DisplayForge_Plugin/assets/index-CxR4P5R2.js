import{c as p,a,A as e}from"./store-CpnYSMZ4.js";p(e,{mode:"plugin",store:a("plugin")}).mount("#app");
