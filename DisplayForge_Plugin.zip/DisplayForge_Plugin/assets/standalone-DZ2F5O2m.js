import{c as a,a as e,A as o}from"./store-C_36TxOU.js";a(o,{mode:"standalone",store:e("standalone")}).mount("#app");
